package resources;

import java.util.ListResourceBundle;

public class Resources extends ListResourceBundle {

    private static final Object[][] contents = {
        { "language.eu", "Basque" },
        { "language.es", "Spanish" },
        { "language.en", "English" }
    };

    @Override
    protected Object[][] getContents() {
        return contents;
    }
    
}
