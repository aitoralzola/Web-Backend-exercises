package controller;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import domain.user.dao.UserFacade;
import domain.user.model.User;

@WebServlet(name = "LgoinController", urlPatterns = { "/login" })
public class LoginController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public LoginController() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get parameters from the request
        String action = Optional.ofNullable(request.getParameter("action")).orElse("logout");
        String username = Optional.ofNullable(request.getParameter("username")).orElse("");
        String password = Optional.ofNullable(request.getParameter("password")).orElse("");
        HttpSession session = request.getSession(true);

        switch (action) {
        case "login":
            login(session, username, password);
            break;
        case "logout":
        default:
            logout(session);
        }
        response.sendRedirect("index.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

    private void login(HttpSession session, String username, String password) {
        User user;

        // Check if the user exists in the database
        UserFacade uf = new UserFacade();
        user = uf.loadUser(username, password);

        // Save login result in session
        if (user != null) {
            session.setAttribute("user", user);
            session.setAttribute("message", "Successfully logged!");
        } else {
            session.removeAttribute("user");
            session.setAttribute("wrongUsername", username);
            session.setAttribute("error", "Wrong username or password.");
        }
    }

    private void logout(HttpSession session) {
        session.removeAttribute("user");
        session.setAttribute("message", "You logged out.");
    }

}
