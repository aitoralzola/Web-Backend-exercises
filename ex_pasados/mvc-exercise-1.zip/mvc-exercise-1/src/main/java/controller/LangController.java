package controller;

import java.io.IOException;
import java.util.Locale;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.jstl.core.Config;

@WebServlet( name = "LangController", urlPatterns = "/lang" )
public class LangController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String language = Optional.ofNullable(request.getParameter("language")).orElse("en");
        String country = Optional.ofNullable(request.getParameter("country")).orElse("UK");

        if (!language.isBlank() && !country.isBlank()) {
            Locale locale = new Locale(language, country);
            Config.set(request.getSession(), javax.servlet.jsp.jstl.core.Config.FMT_LOCALE, locale);
        }
        response.sendRedirect(request.getHeader("/index.jsp"));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
