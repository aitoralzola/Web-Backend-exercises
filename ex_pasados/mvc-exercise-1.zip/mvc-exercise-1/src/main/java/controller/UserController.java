package controller;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import domain.user.dao.UserFacade;
import domain.user.model.User;

@WebServlet ( name = "UserController ", urlPatterns = "/user")
public class UserController extends HttpServlet {
    
    private UserFacade uFacade = new UserFacade();

    /**
     * Get the user list from the facade and put it into the session as an attribute.
     * @param session The current active session.
     */
    private void getUserList(HttpSession session) {
        session.setAttribute("userList", uFacade.loadUsers());
    }

    /**
     * Get the user that we want to search using it's ID.
     * @param session The current active session.
     * @param userId The id of the user we want to search.
     */
    private void getUserFromSearch(HttpSession session, String userId) {
        if (!userId.equals("")) {
            session.setAttribute("userSearch", uFacade.loadUser(Integer.parseInt(userId)));
        }
    }

    /**
     * Create a new user in the user table at the database.
     * @param request The recuest from the server.
     * @return The id of the new user.
     */
    private int createNewUser(HttpServletRequest request) {
        User user = new User();
        user.setUser(
            -1,
            Optional.ofNullable(request.getParameter("username")).orElse("empty"),
            Optional.ofNullable(request.getParameter("firstName")).orElse("empty"),
            Optional.ofNullable(request.getParameter("secondName")).orElse("empty"),
            Optional.ofNullable(request.getParameter("password")).orElse("empty"),
            Optional.ofNullable(request.getParameter("email")).orElse("empty")
        );
        return uFacade.createUser(user);
    }

    /**
     * Set the user that is going to be updated as a session variable.
     * @param session The current active session.
     * @param userId The id of the user.
     */
    private void getUserUpdate(HttpSession session, String userId) {
        if (!userId.equals("")) {
            session.setAttribute("updateUser", uFacade.loadUser(Integer.parseInt(userId)));
            session.setAttribute("userId", userId);
        }
    }

    /**
     * Update a user on the database.
     * @param request The request from the server.
     * @param userId The id of the updated user.
     * @return The id of the updated user.
     */
    private void updateUser(HttpServletRequest request, int userId) {
        uFacade.editUser(
            userId,
            Optional.ofNullable(request.getParameter("username")).orElse("empty"),
            Optional.ofNullable(request.getParameter("password")).orElse("empty"),
            Optional.ofNullable(request.getParameter("firstName")).orElse("empty"),
            Optional.ofNullable(request.getParameter("secondName")).orElse("empty"),
            Optional.ofNullable(request.getParameter("email")).orElse("empty")
        );
    }

    /**
     * Remove a user from the database.
     * @param userId The id of the user that is going to be removed.
     */
    private void removeUser(String userId) {
        if (!userId.equals("")) {
            uFacade.removeUser(Integer.parseInt(userId));
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userId = Optional.ofNullable(request.getParameter("userId")).orElse("");
        String action = Optional.ofNullable(request.getParameter("action")).orElse("");
        HttpSession session = request.getSession();
        RequestDispatcher dispatcher = null;

        switch (action) {
            case "create":
                dispatcher = getServletContext().getRequestDispatcher("/view/user_form.jsp");
                dispatcher.forward(request, response);
                break;
            case "view":
                getUserFromSearch(session, userId);
                dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
                dispatcher.forward(request, response);
                break;
            case "edit":
                getUserUpdate(session, userId);
                dispatcher = getServletContext().getRequestDispatcher("/view/user_form.jsp");
                dispatcher.forward(request, response);
                break;
            case "delete":
                removeUser(userId);
                response.sendRedirect(response.encodeRedirectURL("/user?action=list"));
                break;
            case "list":
            default:
                getUserList(session);
                dispatcher = getServletContext().getRequestDispatcher("/view/user_list.jsp");
                dispatcher.forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = Optional.ofNullable(request.getParameter("action")).orElse("");
        HttpSession session = request.getSession();
        String userId = (String)(session.getAttribute("userId"));
        
        switch (action) {
            case "create":
                userId = String.valueOf(createNewUser(request));
                response.sendRedirect(response.encodeRedirectURL("/user?action=view&userId=" + userId));
                break;
            case "edit":
                updateUser(request, Integer.parseInt(userId));
                response.sendRedirect(response.encodeRedirectURL("/user?action=view&userId=" + userId));
                break;
            default: doGet(request, response);
        }
        if (!userId.equals("")) {
            session.removeAttribute("userId");
        }
    }
}
