package domain.user.dao;
import java.util.ArrayList;

import domain.user.model.User;

public interface DaoUser {
    public int insertUser(User user);
    public User loadUser(String username, String password);
    public User loadUser(int userId);
    public ArrayList<User> loadUsers();
    public void editUser(int userId, String name, String pass, String fName, String sName, String email);
    public void removeUser(int userId);
}
