package domain.user.dao;

import java.util.ArrayList;

import config.MySQLConfig;
import domain.user.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DaoUserMySQL implements DaoUser {

	private MySQLConfig mysqlConfig;

	public DaoUserMySQL() {
		mysqlConfig = MySQLConfig.getInstance();
	}

    private int getHighestID() {
        String sqlQuery = "SELECT userId FROM user ORDER BY userId DESC LIMIT 1";
        Connection connection = mysqlConfig.connect();
        int value = 1;

        try {
            ResultSet set = connection.prepareStatement(sqlQuery).executeQuery();
            if (set.next()) {
                value = set.getInt("userId") + 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return value;
    }

	@Override
	public int insertUser(User user) {
        String sqlQuery = "INSERT INTO user VALUES (?, ?, ?, ?, ?, ?)";
        Connection connection = mysqlConfig.connect();
        PreparedStatement pStm = null;
        user.setUserId(getHighestID());

        try {
            pStm = connection.prepareStatement(sqlQuery);
            pStm.setInt(1, user.getUserId());
            pStm.setString(2, user.getUsername());
            pStm.setString(3, user.getPassword());
            pStm.setString(4, user.getFirstName());
            pStm.setString(5, user.getSecondName());
            pStm.setString(6, user.getEmail());
            pStm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user.getUserId();
	}

	@Override
	public User loadUser(String username, String password) {
        String sqlQuery = "SELECT * FROM user WHERE username=? AND password=?";
        Connection connection = mysqlConfig.connect();
        PreparedStatement pStm = null;
        User user = null;

        try{
            pStm = connection.prepareStatement(sqlQuery);
            pStm.setString(1, username);
            pStm.setString(2, password);

            ResultSet rs = pStm.executeQuery();
            if(rs.next()) {
                user = new User();
                user.setUserId(rs.getInt("userId"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setFirstName(rs.getString("first_name"));
                user.setSecondName(rs.getString("second_name"));
                user.setEmail(rs.getString("email"));
            }
        }
        catch(SQLException e) {
            e.printStackTrace();
            System.out.println("Error DaoLoginMysql loadUser " + username);
        }
        mysqlConfig.disconnect(connection, pStm);
        return user;
	}

	@Override
	public User loadUser(int userId) {
        String sqlQuery = "SELECT * FROM user WHERE userId=?";
        Connection connection = mysqlConfig.connect();
        PreparedStatement pStm = null;
        User user = null;

        try {
            pStm = connection.prepareStatement(sqlQuery);
            pStm.setInt(1, userId);

            ResultSet rs = pStm.executeQuery();
            if (rs.next()) {
                user = new User();
                user.setUserId(rs.getInt("userId"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setFirstName(rs.getString("first_name"));
                user.setSecondName(rs.getString("second_name"));
                user.setEmail(rs.getString("email"));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
		return user;
	}

	@Override
	public ArrayList<User> loadUsers() {
        Connection connection = mysqlConfig.connect();
        ArrayList<User> userList = new ArrayList<>();
		String sqlQuery = "SELECT * FROM user";

        try {
            ResultSet rs = connection.prepareStatement(sqlQuery).executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("userId"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setFirstName(rs.getString("first_name"));
                user.setSecondName(rs.getString("second_name"));
                user.setEmail(rs.getString("email"));
                userList.add(user);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
		return userList;
	}

    @Override
    public void editUser(int userId, String name, String pass, String fName, String sName, String email) {
        String sqlQuery = "UPDATE user SET username=?, password=?, first_name=?, second_name=?, email=? WHERE userId=?";
        Connection connection = mysqlConfig.connect();
        PreparedStatement pStm = null;

        try {
            pStm = connection.prepareStatement(sqlQuery);
            pStm.setString(1, name);
            pStm.setString(2, pass);
            pStm.setString(3, fName);
            pStm.setString(4, sName);
            pStm.setString(5, email);
            pStm.setInt(6, userId);
            pStm.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void removeUser(int userId) {
        String sqlQuery = "DELETE FROM user WHERE userId=?;";
        Connection connection = mysqlConfig.connect();
        PreparedStatement pStm = null;

        try {
            pStm = connection.prepareStatement(sqlQuery);
            pStm.setInt(1, userId);
            pStm.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
