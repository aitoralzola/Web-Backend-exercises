package domain.user.dao;

import java.util.ArrayList;

import domain.user.model.User;

public class UserFacade {
	DaoUser daoUser = null;
	
	public UserFacade() {
		daoUser = new DaoUserMySQL();
	}

	/**
	 * CREATE:
	 * Add a new user to the database.
	 * @param user The new user.
	 * @return The id of the new user.
	 */
	public int createUser(User user) {
		return daoUser.insertUser(user);
	}

	/**
	 * READ:
	 * Get the information of a user using it's username and password.
	 * @param username The username of a user.
	 * @param password The password of the user.
	 * @return The user from the database. Null if not found.
	 */
	public User loadUser(String username, String password) {
		return daoUser.loadUser(username, password);
	}

	/**
	 * READ:
	 * Get the information of a user using it's id.
	 * @param userId Identificator number of the user.
	 * @return The user from the database. Null if not found.
	 */
	public User loadUser(int userId) {
		return daoUser.loadUser(userId);
	}

	/**
	 * READ:
	 * Get all the users from the user table.
	 * @return A list of all users.
	 */
	public ArrayList<User> loadUsers() {
		return daoUser.loadUsers();
	}

	/**
	 * UPDATE:
	 * Change a parameter of a user.
	 * @param userId userId.
	 * @param name username.
	 * @param pass password.
	 * @param fName First name.
	 * @param sName Second name.
	 * @param email email.
	 */
	public void editUser(int userId, String name, String pass, String fName, String sName, String email) {
		daoUser.editUser(userId, name, pass, fName, sName, email);
	}

	/**
	 * DELETE:
	 * Remove a user from the user table.
	 * @param userId The id of the user that is going to be removed.
	 */
	public void removeUser(int userId) {
		daoUser.removeUser(userId);
	}
}
